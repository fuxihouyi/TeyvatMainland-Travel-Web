$(function(){



    $('.tooltip-test').tooltip();
    $('.popover-test').popover();


});
